package data_io;

import java.io.*;
import java.util.*;

public class FileIO {
	
	public PrintWriter fileOut(String name) throws IOException {
		
		// (����6-4) ���� ��ġ
		PrintWriter out = new PrintWriter(new File(name));
		out.print("");
		return out;
	}
	
	public Scanner fileIn(String name) throws IOException {
		
		// (����6-4) ���� ��ġ
		
		Scanner sc = new Scanner(new File(name));
		return sc;
	}
}