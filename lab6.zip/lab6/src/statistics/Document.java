package statistics;

public class Document {
	String[] list;
	int[] counter = new int[26];
	
	public String[] splitWords(String s) {
		
		// (����6-3) ���� ��ġ
		list = s.split(" ");
		return list;
	}
	
	public int[] countLetters(String[] wordList) {
		
		// (����6-3) ���� ��ġ
		for (String word : list) {
			for (char c : word.toCharArray()) {
				for (int i = 0; i < counter.length; i++) {
					if (c == (char) (97 + i) ) {
						counter[i]++;
					}
				}
			}
		}
		
		return counter;
	}
	
	public int totalLetters(int[] countArray) {
		
		// (����6-3) ���� ��ġ
		int total = 0;
		for (int num:counter) {
			total += num;
		}
		
		return total;
	}
}
