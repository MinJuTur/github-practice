package game;

import java.util.Random;

public class WordGame {
	String[] wordArray;
	Random r = new Random();
	
	public WordGame(String[] words) {
		
		// (����6-1) ���� ��ġ
		wordArray = words;
	}
	
	public String selectWord() {
		
		// (����6-1) ���� ��ġ
		int index = (int) Math.random() * wordArray.length;
		return wordArray[index];
	}
	
	public static boolean check(String s, StringBuffer a, char ch) {
		
		// (����6-1) ���� ��ġ
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ch) {
				a.replace(i, i+1, Character.toString(ch));
			}
		}
		
		if (s.equals(a.toString())) {
			return true;
		} else {
			return false;
		}
	}

}
